particle end_rod 16.3 16.3 16.3 0 0 0 0 1 force
particle end_rod 16.42 16.42 16.42 0 0 0 0 1 force
particle end_rod 16.53 16.53 16.53 0 0 0 0 1 force
particle end_rod 16.65 16.65 16.65 0 0 0 0 1 force
particle end_rod 16.76 16.76 16.76 0 0 0 0 1 force
particle end_rod 16.88 16.88 16.88 0 0 0 0 1 force
particle end_rod 16.99 16.99 16.99 0 0 0 0 1 force
particle end_rod 17.11 17.11 17.11 0 0 0 0 1 force
