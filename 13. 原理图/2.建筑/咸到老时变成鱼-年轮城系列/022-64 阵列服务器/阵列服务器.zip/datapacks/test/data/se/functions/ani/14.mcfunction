particle end_rod 13.41 13.41 13.41 0 0 0 0 1 force
particle end_rod 13.53 13.53 13.53 0 0 0 0 1 force
particle end_rod 13.64 13.64 13.64 0 0 0 0 1 force
particle end_rod 13.76 13.76 13.76 0 0 0 0 1 force
particle end_rod 13.87 13.87 13.87 0 0 0 0 1 force
particle end_rod 13.99 13.99 13.99 0 0 0 0 1 force
particle end_rod 14.1 14.1 14.1 0 0 0 0 1 force
particle end_rod 14.22 14.22 14.22 0 0 0 0 1 force
