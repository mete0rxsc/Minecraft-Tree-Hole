particle end_rod 10.52 10.52 10.52 0 0 0 0 1 force
particle end_rod 10.64 10.64 10.64 0 0 0 0 1 force
particle end_rod 10.75 10.75 10.75 0 0 0 0 1 force
particle end_rod 10.87 10.87 10.87 0 0 0 0 1 force
particle end_rod 10.98 10.98 10.98 0 0 0 0 1 force
particle end_rod 11.1 11.1 11.1 0 0 0 0 1 force
particle end_rod 11.21 11.21 11.21 0 0 0 0 1 force
particle end_rod 11.33 11.33 11.33 0 0 0 0 1 force
