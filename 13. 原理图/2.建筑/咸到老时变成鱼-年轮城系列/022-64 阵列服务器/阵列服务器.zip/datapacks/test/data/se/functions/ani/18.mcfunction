particle end_rod 17.23 17.23 17.23 0 0 0 0 1 force
particle end_rod 17.34 17.34 17.34 0 0 0 0 1 force
particle end_rod 17.46 17.46 17.46 0 0 0 0 1 force
particle end_rod 17.57 17.57 17.57 0 0 0 0 1 force
particle end_rod 17.69 17.69 17.69 0 0 0 0 1 force
particle end_rod 17.8 17.8 17.8 0 0 0 0 1 force
particle end_rod 17.92 17.92 17.92 0 0 0 0 1 force
particle end_rod 18.03 18.03 18.03 0 0 0 0 1 force
