particle end_rod 1.04 1.04 1.04 0 0 0 0 1 force
particle end_rod 1.16 1.16 1.16 0 0 0 0 1 force
particle end_rod 1.27 1.27 1.27 0 0 0 0 1 force
particle end_rod 1.39 1.39 1.39 0 0 0 0 1 force
particle end_rod 1.5 1.5 1.5 0 0 0 0 1 force
particle end_rod 1.62 1.62 1.62 0 0 0 0 1 force
particle end_rod 1.73 1.73 1.73 0 0 0 0 1 force
particle end_rod 1.85 1.85 1.85 0 0 0 0 1 force
