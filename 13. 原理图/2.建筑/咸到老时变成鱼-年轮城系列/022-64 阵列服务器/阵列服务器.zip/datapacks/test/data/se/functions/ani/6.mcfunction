particle end_rod 5.78 5.78 5.78 0 0 0 0 1 force
particle end_rod 5.9 5.9 5.9 0 0 0 0 1 force
particle end_rod 6.01 6.01 6.01 0 0 0 0 1 force
particle end_rod 6.13 6.13 6.13 0 0 0 0 1 force
particle end_rod 6.24 6.24 6.24 0 0 0 0 1 force
particle end_rod 6.36 6.36 6.36 0 0 0 0 1 force
particle end_rod 6.47 6.47 6.47 0 0 0 0 1 force
particle end_rod 6.59 6.59 6.59 0 0 0 0 1 force
