particle end_rod 2.89 2.89 2.89 0 0 0 0 1 force
particle end_rod 3.01 3.01 3.01 0 0 0 0 1 force
particle end_rod 3.12 3.12 3.12 0 0 0 0 1 force
particle end_rod 3.24 3.24 3.24 0 0 0 0 1 force
particle end_rod 3.35 3.35 3.35 0 0 0 0 1 force
particle end_rod 3.47 3.47 3.47 0 0 0 0 1 force
particle end_rod 3.58 3.58 3.58 0 0 0 0 1 force
particle end_rod 3.7 3.7 3.7 0 0 0 0 1 force
