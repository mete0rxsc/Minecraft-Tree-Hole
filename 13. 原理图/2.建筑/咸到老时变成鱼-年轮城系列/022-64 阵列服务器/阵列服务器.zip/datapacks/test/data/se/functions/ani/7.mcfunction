particle end_rod 6.71 6.71 6.71 0 0 0 0 1 force
particle end_rod 6.82 6.82 6.82 0 0 0 0 1 force
particle end_rod 6.94 6.94 6.94 0 0 0 0 1 force
particle end_rod 7.05 7.05 7.05 0 0 0 0 1 force
particle end_rod 7.17 7.17 7.17 0 0 0 0 1 force
particle end_rod 7.28 7.28 7.28 0 0 0 0 1 force
particle end_rod 7.4 7.4 7.4 0 0 0 0 1 force
particle end_rod 7.51 7.51 7.51 0 0 0 0 1 force
