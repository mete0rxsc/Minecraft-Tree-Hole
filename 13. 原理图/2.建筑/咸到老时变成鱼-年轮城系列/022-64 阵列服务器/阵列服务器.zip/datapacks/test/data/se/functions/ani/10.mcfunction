particle end_rod 9.6 9.6 9.6 0 0 0 0 1 force
particle end_rod 9.71 9.71 9.71 0 0 0 0 1 force
particle end_rod 9.83 9.83 9.83 0 0 0 0 1 force
particle end_rod 9.94 9.94 9.94 0 0 0 0 1 force
particle end_rod 10.06 10.06 10.06 0 0 0 0 1 force
particle end_rod 10.17 10.17 10.17 0 0 0 0 1 force
particle end_rod 10.29 10.29 10.29 0 0 0 0 1 force
particle end_rod 10.4 10.4 10.4 0 0 0 0 1 force
