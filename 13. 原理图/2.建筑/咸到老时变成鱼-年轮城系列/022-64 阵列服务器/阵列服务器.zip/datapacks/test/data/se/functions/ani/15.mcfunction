particle end_rod 14.34 14.34 14.34 0 0 0 0 1 force
particle end_rod 14.45 14.45 14.45 0 0 0 0 1 force
particle end_rod 14.57 14.57 14.57 0 0 0 0 1 force
particle end_rod 14.68 14.68 14.68 0 0 0 0 1 force
particle end_rod 14.8 14.8 14.8 0 0 0 0 1 force
particle end_rod 14.91 14.91 14.91 0 0 0 0 1 force
particle end_rod 15.03 15.03 15.03 0 0 0 0 1 force
particle end_rod 15.14 15.14 15.14 0 0 0 0 1 force
