particle end_rod 8.67 8.67 8.67 0 0 0 0 1 force
particle end_rod 8.79 8.79 8.79 0 0 0 0 1 force
particle end_rod 8.9 8.9 8.9 0 0 0 0 1 force
particle end_rod 9.02 9.02 9.02 0 0 0 0 1 force
particle end_rod 9.13 9.13 9.13 0 0 0 0 1 force
particle end_rod 9.25 9.25 9.25 0 0 0 0 1 force
particle end_rod 9.36 9.36 9.36 0 0 0 0 1 force
particle end_rod 9.48 9.48 9.48 0 0 0 0 1 force
