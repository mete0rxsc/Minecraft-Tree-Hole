particle end_rod 18.15 18.15 18.15 0 0 0 0 1 force
particle end_rod 18.27 18.27 18.27 0 0 0 0 1 force
particle end_rod 18.38 18.38 18.38 0 0 0 0 1 force
particle end_rod 18.5 18.5 18.5 0 0 0 0 1 force
particle end_rod 18.61 18.61 18.61 0 0 0 0 1 force
particle end_rod 18.73 18.73 18.73 0 0 0 0 1 force
particle end_rod 18.84 18.84 18.84 0 0 0 0 1 force
particle end_rod 18.96 18.96 18.96 0 0 0 0 1 force
