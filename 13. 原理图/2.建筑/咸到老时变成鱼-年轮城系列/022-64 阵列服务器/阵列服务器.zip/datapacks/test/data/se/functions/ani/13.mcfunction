particle end_rod 12.49 12.49 12.49 0 0 0 0 1 force
particle end_rod 12.6 12.6 12.6 0 0 0 0 1 force
particle end_rod 12.72 12.72 12.72 0 0 0 0 1 force
particle end_rod 12.83 12.83 12.83 0 0 0 0 1 force
particle end_rod 12.95 12.95 12.95 0 0 0 0 1 force
particle end_rod 13.06 13.06 13.06 0 0 0 0 1 force
particle end_rod 13.18 13.18 13.18 0 0 0 0 1 force
particle end_rod 13.29 13.29 13.29 0 0 0 0 1 force
